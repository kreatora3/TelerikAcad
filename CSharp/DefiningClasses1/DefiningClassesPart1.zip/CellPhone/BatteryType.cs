﻿namespace CellPhone
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
   /// <summary>
    ///  Enumeration
   /// </summary>
    public enum BatteryType
    {
        LiPoly,
        LiIon,
        NiCd,
        NiMH
    }
}
