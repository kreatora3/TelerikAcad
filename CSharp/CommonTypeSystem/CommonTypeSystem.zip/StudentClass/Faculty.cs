﻿namespace StudentClass
{
    public enum Faculty
    {
        Math,
        Historical,
        Philosophy,
        Biology
    }
}
