﻿namespace StudentClass
{
    public enum Specialty
    {
        Math,
        History,
        Biology,
        Physics,
        Philosophy
    }
}
