﻿namespace StudentClass
{
    public enum University
    {
        SofiaUni,
        Technical,
        UNSS
    }
}
