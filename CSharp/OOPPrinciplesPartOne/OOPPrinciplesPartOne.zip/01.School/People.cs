﻿namespace _01.School
{
    using System;

    public abstract class People
    {
        public string Name { get; protected set; }
    }
}
