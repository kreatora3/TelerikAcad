﻿namespace _01.School
{
    public interface IComment
    {
        string OptionalComment
        {
            get;
            set;
        }
    }
}
