﻿namespace BankSystem
{
    public interface IWithdrawable
    {
        decimal Withdraw(decimal a, decimal b);
    }
}
