﻿namespace BankSystem
{
    public class Company : Customer
    {
        public Company(string name)
            : base(name)
        {
        }
    }
}
