(function () {
    "use strict";
    var game = Game.createGame();
    game.run();
})();