﻿function inputValueGetter() {

   var result = document.getElementById('problem2').value;

    document.getElementById('output2').innerHTML = result;
}