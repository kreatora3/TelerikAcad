﻿function paint() {

    var color = document.getElementById('problem3').value;

    document.body.style.backgroundColor = color;
}