﻿function countDivs() {

    var count = document.getElementsByTagName('div').length;

    document.getElementById('result4').innerHTML = 'There are ' + count + ' divs'
}