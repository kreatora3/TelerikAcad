define(['jquery', 'combo'], function ($, comboBox) {

    return  {
        ComboBox: function (people) {
            return new comboBox(people)
        }}
})

