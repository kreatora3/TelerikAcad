define([], function () {

    var people = [
        {
            id: 1,
            name: "Doncho Minkov",
            age: 18,
            avatarUrl: "images/minkov.jpg"
        },
        {
            id: 2,
            name: "Georgi Georgiev",
            age: 19,
            avatarUrl: "images/joreto.jpg"
        },

        {
            id: 3,
            name: "Kotio",
            age: 19,
            avatarUrl: "images/third.jpg"
        },
        {
            id: 4,
            name: "Sphere",
            age: 19,
            avatarUrl: "images/fourth.jpeg"
        }
    ];

    return people
})

