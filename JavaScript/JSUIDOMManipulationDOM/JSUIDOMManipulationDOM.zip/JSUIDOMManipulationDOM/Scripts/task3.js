﻿
function fontChange() {
    var newColor = document.getElementById('fontColor').value;
    document.getElementById("targetArea").style.color = newColor;
}
function backgroundChange() {
    var newColor = document.getElementById('backgroundColor').value;
    document.getElementById("targetArea").style.backgroundColor = newColor;
}