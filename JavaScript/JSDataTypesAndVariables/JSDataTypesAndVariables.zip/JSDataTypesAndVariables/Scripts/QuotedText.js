﻿console.log('Task 2 - Data Types and Variables');
console.log('');

var quotedText = " 'How you doin\'\?', Joey said.";
console.log(quotedText);
console.log('');