﻿console.log('Task 4 - Data Types and Variables');
console.log('');

var n = null;
var u = undefined;

console.log(typeof n);
console.log('');
console.log(typeof u);
console.log('');